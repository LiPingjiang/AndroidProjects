package com.pli.yotaphone2.auxiliary;

import android.app.Notification;

/**
 * Created by Pingjiang.Li on 05/07/15.
 */
public class Data {
    public String longitude = new String();
    public String altitude = new String();  //location
    public String gravity = new String();
    public Notification noti;          //notification
    public String activity_name = new String();
    public String activity_type = new String();
    public String activity_confidence = new String();
}
